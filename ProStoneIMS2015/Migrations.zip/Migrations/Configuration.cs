using Microsoft.AspNet.Identity;

namespace ProStoneIMS2015.Migrations
{
    using Microsoft.AspNet.Identity;
    using Microsoft.AspNet.Identity.EntityFramework;
    using Models;
    using System;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;

    internal sealed class Configuration : DbMigrationsConfiguration<ProStoneIMS2015.Models.ApplicationDbContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
        }

        protected override void Seed(ProStoneIMS2015.Models.ApplicationDbContext context)
        {
            //  This method will be called after migrating to the latest version.

            //  You can use the DbSet<T>.AddOrUpdate() helper extension method 
            //  to avoid creating duplicate seed data. E.g.
            //
            var manager = new UserManager<ApplicationUser>(new UserStore<ApplicationUser>(new ApplicationDbContext()));
            var roleManager = new RoleManager<IdentityRole>(new RoleStore<IdentityRole>(new ApplicationDbContext()));

            roleManager.Create(new IdentityRole("admin"));
            roleManager.Create(new IdentityRole("subscriber"));
            roleManager.Create(new IdentityRole("user"));

            context.Subscribers.AddOrUpdate(
              p => p.CompanyName,
              new Subscriber { CompanyName = "DFW Wholesale Granite", Email = "dhitt0327@gmail.com", SubscriberKey = "dfw123", FirstName = "David", LastName = "Hitt" },
              new Subscriber { CompanyName = "ProStone Philippines", Email = "hubert17@facebook.com", SubscriberKey = "psp117", FirstName = "Bernard", LastName = "Gabon" }
            );

            var subscriberUser = manager.FindByName("dhitt0327@gmail.com");
            manager.AddToRoles(subscriberUser.Id, new string[] { "subscriber", "user" });
            subscriberUser = manager.FindByName("hubert17@facebook.com");
            manager.AddToRoles(subscriberUser.Id, new string[] { "subscriber", "user" });

        }
    }
}
