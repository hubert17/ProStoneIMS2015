﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using ProStoneIMS2015.Models;

namespace ProStoneIMS2015.Controllers
{
    public class SettingsController : Controller
    {
        private ApplicationDbContext db = new ApplicationDbContext();

        // GET: Settings/Edit/5
        public ActionResult Index()
        {
            Subscriber subscriber = db.Subscribers.FirstOrDefault();
            if (subscriber == null)
            {
                return HttpNotFound();
            }
            return View(subscriber);
        }

        // POST: Settings/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Index(Subscriber subscriber)
        {
            if (ModelState.IsValid)
            {
                var entry = db.Entry(db.Subscribers.Single(d => d.TenantId == subscriber.TenantId));
                var excluded = new[] { "TenantId","SubscriberKey","FirstName","LastName","Phone","Email","AltEmail","MembershipDate","Inactive" };
                foreach (var name in excluded)
                {
                    entry.Property(name).IsModified = false;
                }

                db.SaveChanges();
                return Json(new
                {
                    success = true,
                    action = "edit",
                    col = new[] {
                        subscriber.TenantId.ToString(),
                        subscriber.CompanyName,
                        subscriber.Address,
                        subscriber.City,
                        subscriber.State
                    }
                });
            }
            return View(subscriber);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
