﻿    $(function () {
        $.ajaxSetup({ cache: false });
        //$("a[data-modal]").on("click", function (e) {        
        $(document).on("click", "a[data-modal]", function (e) {
            $(this).closest('tr').addClass("selectedRow");
            $('div.modal').on('hidden.bs.modal', function () {
                $('#grid tbody tr.selectedRow').removeClass("selectedRow");
            });
            $('#myModalContent').load(this.href, function () {
                $('#psModal').modal({
                    keyboard: true
                }, 'show');

                bindForm(this);
            });
            return false;
        });


    });

    function bindForm(dialog) {
        $('form', dialog).submit(function () {
            $('#progress').show();
            $.ajax({
                url: this.action,
                type: this.method,
                data: $(this).serialize(),
                success: function (result) {
                    if (result.success) {
                        $('#psModal').modal('hide');
                        $('#progress').hide();
                        //location.reload();
                        if (result.action == "edit") {
                            var _selectedRow = $("#grid tbody tr.selectedRow td");
                            _selectedRow.each(function (index) {
                                if (index < _selectedRow.length - 1) {
                                    var tdchild = index + 1;
                                    $("tr.selectedRow td:nth-child(" + tdchild + ")").text(result.col[index]);
                                }
                            });
                        }
                        else if(result.action == "delete") {
                            $("#grid tbody tr.selectedRow").remove();
                        }
                        else if (result.action == "insert") {
                            $("#grid > tbody tr:first").clone().addClass("newRow").prependTo("#grid > tbody");
                            var _newRow = $("#grid tbody tr.newRow td");
                            _newRow.each(function (index) {
                                if (index < _newRow.length - 1) {
                                    var tdchild = index + 1;
                                    $("tr.newRow td:nth-child(" + tdchild + ")").text(result.col[index]);
                                }
                                $('tr.newRow td:last-child a[title="Detail"]').attr("href", result.ctrl + "/details/" + result.id);
                                $('tr.newRow td:last-child a[title="Edit"]').attr("href", result.ctrl + "/edit/" + result.id);
                                $('tr.newRow td:last-child a[title="Delete"]').attr("href", result.ctrl + "/delete/" + result.id);
                            });
                        }

                    } else {
                        $('#progress').hide();
                        if (this.method == "POST") {
                            $('#myModalContent').html(result);
                        }
                        bindForm();                        
                    }
                }
            });
            return false;
        });
    }

    $(document).ready(function () {
        $("#grid tbody tr").each(function (i, row) {
            var $actualRow = $(row);
            if ($actualRow.find('input[type=checkbox]').prop('checked') == true) {
                $actualRow.addClass('text-muted');
            }
        });
    });


