﻿var gabsApp = angular.module("gabsApp", ['ui.bootstrap']);


gabsApp.controller("MeasureCtrl", ['$scope', '$http', function ($scope, $http) {
    $scope.measureSets = {
        items: [{
            setId: null,
        }]
    };

    $scope.measures = {
        items: [{
            length: '',
            measurename: '',
            width: ''
        }]
    };

    $scope.addItem = function () {
        $scope.measures.items.push({
            length: '',
            measurename: $index,
            width: ''
        });
    },

    $scope.removeItem = function (index) {
        $scope.measures.items.splice(index, 1);
    },

    $scope.total = function () {
        var total = 0;
        angular.forEach($scope.measures.items, function (item) {
            total += (item.length * item.width) / 144;
        })
        $scope.Math = window.Math;
        return Math.ceil(total);
    }

    $scope.TotalInput = function () {
        if ($scope.total() > 0)
            return true;
        else
            return false;
    };

    $scope.showhide = true;
    $scope.toggleShowhide = function () {
        $scope.showhide = $scope.showhide === false ? true : false;
    };

}]);



//Inventory
var urlStone = ROOT + 'api/stone/';

gabsApp.factory('inventoryFactory', function ($http) {
    return {
        getModel: function (Id) {
            return $http.get(urlStone + "?stoneId=" + Id);
        },
        updateModel: function (Id, QuoteId) {
            return $http.put(urlStone + "?Id=" + Id + "&QuoteId=" + QuoteId);
        }
    };
});
gabsApp.controller('StoneCtrl', function myController($scope, inventoryFactory) {
    $scope.loading = true;
    this.saving = false;
    $scope.inventoryModel = [];
    $scope.holdinv = [];

    $scope.holdInventory = function (Id) {
        if (this.inventory.QuoteId != -1) {
            $scope.holdinv.push({
                HoldId: Id
            });
            this.inventory.QuoteId = -1;
        }
        else {
            var index = $scope.holdinv.indexOf(Id);
            $scope.holdinv.splice(index, 1);
            this.inventory.QuoteId = null;
        }
    };

    //get all Data
    $scope.loadInventory = function (Id) {
        inventoryFactory.getModel(Id).success(function (data) {
            //alert('heo ' + data)
            $scope.inventoryModel = data;
            $scope.holdinv = [];
            $scope.loading = false;
        })
        .error(function (data) {
            $scope.addAlert('danger', 'An Error has occured while loading Inventory data! ' + data.ExceptionMessage);
            $scope.loading = false;
        });
    };
});


gabsApp.controller("SinkCtrl", ['$scope', '$http', function ($scope, $http) {

    $scope.sinks = {
        items: [{
            sinkID: '',
            sinkqty: '1',
            sinkprice: null,
        }]
    };

    $scope.addItem = function () {
        $scope.sinks.items.push({
            sinkID: '',
            sinkqty: '1',
            sinkprice: null,
        });
    },

    $scope.setDdlSink = function (index, SinkID) {
        //$scope.sinks.items.item.sinkID
    },

    $scope.removeItem = function (index) {
        $scope.sinks.items.splice(index, 1);
    },

    $scope.showhide = true;
    $scope.toggleShowhide = function () {
        $scope.showhide = $scope.showhide === false ? true : false;
    };

}]);

gabsApp.controller("ServiceCtrl", ['$scope', '$http', function ($scope, $http) {

    $scope.services = {
        items: [{
            serviceID: '',
            serviceqty: '1',
            serviceprice: null,
        }]
    };

    $scope.addItem = function () {
        $scope.services.items.push({
            serviceID: '',
            serviceqty: '1',
            serviceprice: null,
        });
    },

    $scope.setDdlService = function (index, ServiceID) {
        //$scope.services.items.item.serviceID
    },

    $scope.removeItem = function (index) {
        $scope.services.items.splice(index, 1);
    },

    $scope.showhide = true;
    $scope.toggleShowhide = function () {
        $scope.showhide = $scope.showhide === false ? true : false;
    };

}]);


gabsApp.filter('ceil', function () {
    return function (input) {
        return Math.ceil(input);
    };
});

gabsApp.directive('ngModelOnblur', function () {
    return {
        restrict: 'A',
        require: 'ngModel',
        priority: 1,
        link: function (scope, elm, attr, ngModelCtrl) {
            if (attr.type === 'radio' || attr.type === 'checkbox') return;

            elm.unbind('input').unbind('keydown').unbind('change');
            elm.bind('blur', function () {
                scope.$apply(function () {
                    ngModelCtrl.$setViewValue(elm.val());
                });
            });
        }
    };
});

gabsApp.directive('elastic', [
    '$timeout',
    function ($timeout) {
        return {
            restrict: 'A',
            link: function ($scope, element) {
                var resize = function () {
                    return element[0].style.height = "" + element[0].scrollHeight + "px";
                };
                element.on("blur keyup change", resize);
                $timeout(resize, 0);
            }
        };
    }
]);