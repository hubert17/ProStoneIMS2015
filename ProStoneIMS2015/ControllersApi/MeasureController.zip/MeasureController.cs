﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using ProStoneIMS2015.Models;

namespace ProStoneIMS2015.ControllersApi
{
    public class MeasureController : ApiController
    {
        private ApplicationDbContext db = new ApplicationDbContext();

        public object GetMeasureLookup(bool? Lookup)
        {
            return db.Measurements.ToArray().Select(s => new
            {
                Id = s.Id,
                MeasureName = s.MeasureName,
            })
            .OrderBy(x => x.MeasureName);
        }

        // GET: api/Measure
        public object GetQuoteMeasuresByQuoteStone(int? QuoteStoneId, int QuoteId)
        {
            //return db.QuoteMeasures.Where(x => x.QuoteStoneId == QuoteStoneId && x.QuoteId == QuoteId);
            var measureData = from q in db.QuoteMeasures
                              where q.QuoteStoneId == QuoteStoneId && q.QuoteId == QuoteId
                              join t in db.Measurements
                            on q.MeasureId equals t.Id into qt
                              from t in qt.DefaultIfEmpty()
                              select new
                           {
                               Id=q.Id,
                               MeasureId=q.MeasureId,
                               MeasureName=t.MeasureName,
                               Length=q.Length,
                               Width=q.Width
                           };

            return measureData;
        }

        // GET: api/Measure?Quoteid
        public object GetQuoteMeasuresByQuote(int QuoteId)
        {
            //return db.QuoteMeasures.Where(x => x.QuoteStone.QuoteId == QuoteId);
            var measureData = from q in db.QuoteMeasures
                              where q.QuoteId == QuoteId
                              join t in db.Measurements
                              on q.MeasureId equals t.Id into qt
                              from t in qt.DefaultIfEmpty()
                              select new
                              {
                                  Id = q.Id,
                                  MeasureId = q.MeasureId,
                                  MeasureName = t.MeasureName,
                                  Length = q.Length,
                                  Width = q.Width
                              };

            return measureData;
        }

        // GET: api/Measure/5
        [ResponseType(typeof(QuoteMeasure))]
        public IHttpActionResult GetQuoteMeasure(int id)
        {
            QuoteMeasure quoteMeasure = db.QuoteMeasures.Find(id);
            if (quoteMeasure == null)
            {
                return NotFound();
            }

            return Ok(quoteMeasure);
        }

        // PUT: api/Measure/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutQuoteMeasure(int id, QuoteMeasure quoteMeasure)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != quoteMeasure.Id)
            {
                return BadRequest();
            }

            db.Entry(quoteMeasure).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
                var measureData = from q in db.QuoteMeasures
                                  where q.Id == quoteMeasure.Id
                                  join t in db.Measurements
                                on q.MeasureId equals t.Id
                                  select new
                                  {
                                      Id = q.Id,
                                      MeasureId = q.MeasureId,
                                      MeasureName = t.MeasureName,
                                      Length = q.Length,
                                      Width = q.Width
                                  };
                return CreatedAtRoute("DefaultApi", new { id = quoteMeasure.Id }, measureData.FirstOrDefault());
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!QuoteMeasureExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            //return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/Measure
        [ResponseType(typeof(QuoteMeasure))]
        public IHttpActionResult PostQuoteMeasure(QuoteMeasure quoteMeasure)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.QuoteMeasures.Add(quoteMeasure);
            db.SaveChanges();

            var measureData = from q in db.QuoteMeasures
                              where q.Id == quoteMeasure.Id
                              join t in db.Measurements
                            on q.MeasureId equals t.Id
                              select new
                              {
                                  Id = q.Id,
                                  MeasureId = q.MeasureId,
                                  MeasureName = t.MeasureName,
                                  Length = q.Length,
                                  Width = q.Width
                              };
            return CreatedAtRoute("DefaultApi", new { id = quoteMeasure.Id }, measureData.FirstOrDefault());
        }

        // DELETE: api/Measure/5
        [ResponseType(typeof(QuoteMeasure))]
        public IHttpActionResult DeleteQuoteMeasure(int id)
        {
            QuoteMeasure quoteMeasure = db.QuoteMeasures.Find(id);
            if (quoteMeasure == null)
            {
                return NotFound();
            }

            db.QuoteMeasures.Remove(quoteMeasure);
            db.SaveChanges();

            return Ok(quoteMeasure);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool QuoteMeasureExists(int id)
        {
            return db.QuoteMeasures.Count(e => e.Id == id) > 0;
        }
    }
}